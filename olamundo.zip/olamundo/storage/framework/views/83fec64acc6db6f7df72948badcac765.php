<!DOCTYPE html>
<html>
<head>
    <title>Resultado da Avaliação do Sono</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <h1>Resultado da Avaliação do Sono</h1>

    <h2><?php echo e($nome); ?></h2>
    <p>Idade: <?php echo e($idade); ?> anos</p>
    <p>Horas de sono: <?php echo e($sono); ?> por noite</p>
    <p>Qualidade do sono: <strong><?php echo e($qualidade); ?></strong></p>

    <a href="/">Voltar</a>
</body>
</html>
<?php /**PATH C:\Users\sofya\laravel\olamundo\resources\views/sono/resultado.blade.php ENDPATH**/ ?>