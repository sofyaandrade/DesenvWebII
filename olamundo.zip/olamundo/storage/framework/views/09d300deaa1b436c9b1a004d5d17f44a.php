<!DOCTYPE html>
<html>
<head>
    <title>Resultado análise IMC</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <h1>Resultado análise IMC</h1>
    <h2><?php echo e($nome); ?></h2>
    <p>Idade: <?php echo e($idade); ?></p>
    <p>Peso: <?php echo e($peso); ?></p>
    <p>Altura: <?php echo e($altura); ?></p>
    <p>IMC: <?php echo e($imc); ?> - <?php echo e($classificacao); ?></p>
    <a href="/">Voltar</a>
</body>
</html>
<?php /**PATH C:\Users\sofya\laravel\olamundo\resources\views/imc/resultado.blade.php ENDPATH**/ ?>