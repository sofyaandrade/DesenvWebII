<!DOCTYPE html>
<html>
<head>
    <title>Resultado do Cálculo de Consumo</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <h1>Resultado do Cálculo de Consumo</h1>

    <div class="container">
        <div class="result">
            <h3>O valor total do gasto será de:</h3>
            <ul>
                <li><strong><?php echo e($combustivel); ?>:</strong> R$ <?php echo e(number_format($gasto, 2, ',', '.')); ?></li>
            </ul>
        </div>

        <a href="/">Voltar</a>
    </div>
</body>
</html>
<?php /**PATH C:\Users\sofya\laravel\olamundo\resources\views/combustivel/resultado.blade.php ENDPATH**/ ?>