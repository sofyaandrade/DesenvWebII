<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolha uma Avaliação</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Bem-vindo!</h1>
        <p>Escolha uma opção abaixo:</p>
        
        <div class="options">
            <a href="<?php echo e(url('/imc')); ?>" class="btn">Calcular IMC</a>
            <a href="<?php echo e(url('/avaliar-sono')); ?>" class="btn">Avaliar Sono</a>
            <a href="<?php echo e(url('/gasto-combustivel')); ?>" class="btn">Gasto de Combustível</a>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\sofya\laravel\olamundo\resources\views/home.blade.php ENDPATH**/ ?>